# EVA Scope Helm adapter

This chart is an optional Kubernetes deployment adapter. The container images
remain usable with Docker Compose, ECS or another OCI-compatible runtime.
ClickHouse can either be installed as an optional StatefulSet in this chart or
provided by the platform as an external service. The default remains external
so existing installations keep their database lifecycle unchanged.

## ClickHouse modes

| `clickhouse.enabled` | Database topology | Backend credentials |
| --- | --- | --- |
| `false` (default) | External or platform-managed ClickHouse | `secrets.existingSecret` key `clickhouse-password` |
| `true` | In-cluster official ClickHouse image, one instance | Existing Secret containing `clickhouse-password` |

When enabled, the chart uses `clickhouse/clickhouse-server:25.3.6.55` and wires
the Backend to its Service, HTTP port, database, and credential Secret. Create
the `clickhouse-password` key in `secrets.existingSecret` before installation;
set `clickhouse.auth.existingSecret` and `clickhouse.auth.existingSecretKey` if
the database password lives in another Secret. The password is never stored in
the chart or values file. The application Secret also provides
`eva-app-client-secret` in both modes.

When using the application Secret for ClickHouse, `secrets.clickhousePasswordKey`
sets its password key for both the database and Backend.

The single-instance StatefulSet uses a persistent claim mounted at
`/var/lib/clickhouse` by default. Configure storage class, capacity, and
resources for the cluster; use an externally managed topology for HA or
large-scale analytics. The claim remains after Helm uninstall and must be
backed up and removed separately. Existing Bitnami ClickHouse installations
cannot be upgraded to this layout by changing the image: export and restore
the database into a fresh official-image volume before switching releases.

## Fleet Overview automatic collection

`backend.env.SYNC_SCHEDULER_ENABLED` is enabled by default so completed hourly
EVA App dumps are collected into the Fleet Overview rollup automatically. It
must be enabled on exactly one Backend replica because the current scheduler is
process-local, not distributed. The current hour is not collected immediately:
the dump must first complete, then the scheduler picks it up on its next run.

The sync interval, finalization grace period, lookback range, retention, and
batch size are EVA Scope product defaults rather than normal Helm settings. In
the rare case an installation needs to tune one, add the corresponding
environment variable through `backend.extraEnv`.

## Exposure modes

The chart selects its TLS topology with `ingress.enabled` and `proxy.httpOnly`.

| `ingress.enabled` | `proxy.httpOnly` | TLS termination | EVA Scope Proxy |
| --- | --- | --- | --- |
| `false` | `false` (default) | Proxy | HTTP and HTTPS; redirects HTTP to HTTPS |
| `true` | either | Ingress | HTTP-only ClusterIP upstream |
| `false` | `true` | External load balancer | HTTP-only, optionally NodePort |

When Ingress is enabled, the chart creates a Traefik `Ingress` that forwards
all paths to the Proxy HTTP service. Configure HTTP-to-HTTPS redirection at
the platform Ingress or load-balancer layer when required. The proxy remains
in the request path so its API rate limits and long analysis-request timeouts
remain active. Do not expose the Backend or Frontend services directly through
a separate Ingress.

For an external ALB that terminates HTTPS and sends HTTP to an NKS worker,
leave `ingress.enabled: false` and set `proxy.httpOnly: true`,
`proxy.service.type: NodePort`, and `proxy.service.httpNodePort` (e.g. `32090`).
The Service's `httpPort` remains `80` and forwards to the Proxy container's
HTTP port `80`; the ALB target group uses the **node port** instead. The chart
creates no Kubernetes Ingress or Proxy TLS Secret mount in this mode. Use an
HTTP health check on `/ready`. Do not create an ALB target group for the
ClickHouse Service: it is internal to the cluster. Restrict direct access to
the HTTP NodePort to ALB sources using the cluster's network controls.

`proxy.service.httpNodePort` is optional; Kubernetes assigns a free node port
when omitted. It is invalid to set it with a non-NodePort Service. If the
cluster has a custom NodePort range, check that the chosen port is allowed.

Set `ingress.realIp.trustedCidrs` to the Pod or node CIDRs used by the Ingress
Controller. The HTTP-only Proxy then trusts `X-Forwarded-For` only from those
peers and applies its rate limits to the real client address. Leaving it empty
uses the Ingress peer address for rate limiting.
For an external ALB use `proxy.realIp.trustedCidrs` for the actual trusted peer
IPs/CIDRs instead. In Ingress mode this setting takes precedence over the
existing `ingress.realIp.trustedCidrs` when nonempty. Without a trusted peer
the ALB's clients share one rate-limit bucket, including the `1r/m` analysis
limit. Never trust all peers (`0.0.0.0/0`) on a NodePort.

## TLS Secrets

In direct Proxy TLS mode (`ingress.enabled: false`, `proxy.httpOnly: false`),
create the TLS Secret named by `proxy.tls.secretName` before installing. It must
contain the standard `tls.crt` and `tls.key` keys. External ALB mode does not
require a Kubernetes TLS Secret.

In Ingress mode, configure `ingress.tls`:

- `create: false`: create the target TLS Secret through the platform's normal
  Secret-management workflow before installing.
- `create: true`: a Helm post-install/post-upgrade Job reads the certificate
  source and creates or updates the target TLS Secret. The Job runs again on
  Helm upgrade, which is the supported way to refresh a hostPath certificate.

`authType: hostPath` reads files from a node directory. On multi-node clusters,
every eligible node must have that directory, or `ingress.tls.job.nodeSelector`
or affinity must pin the Job to the correct node. `authType: secret` mounts an
existing source Secret; its keys must match `certFile` and `keyFile`.

The created Kubernetes TLS Secret always uses `tls.crt` and `tls.key`, even when
the source files use the Docker Compose names `fullchain.pem` and `privkey.pem`.

The credentials Secret named by `secrets.existingSecret` is always managed
separately for `eva-app-client-secret`. In external ClickHouse mode it must
also contain `clickhouse-password`; the chart never creates application
credentials.

## ECR image pull Secret

`imagePullSecrets` follows the EVA platform's hostPath credential policy by
default. A regular Helm Job mounts `/home/eva/.aws`, obtains an ECR token, and
creates `<release>-secret-regcred`. Backend, Frontend and Proxy then refer to
that generated Docker registry Secret. A periodic CronJob renews the token;
the default schedule is every 10 hours. The initial Job is retained for 30
minutes so it remains observable during Helm `--wait --wait-for-jobs`.

`imagePullSecrets.secretName` is used only with `authType: secret`: it is the
source Secret that contains AWS credentials, not the generated Docker registry
Secret. With `authType: hostPath`, pin the Job through
`imagePullSecrets.cronjob.nodeSelector` or affinity when `/home/eva/.aws` is
not available on every node.

Backend and Frontend image defaults use ECR, but the Proxy, ClickHouse, AWS CLI,
and kubectl images use public registries. The initial ECR Secret Job cannot
pull its own private ECR image without a pre-existing pull Secret. For a
fully private registry, provision and renew a pull Secret independently and
use `ExistingSecret`, then override all image repositories.

Set `ExistingSecret` to use a pull Secret managed outside this chart. The ECR
credential Job, CronJob and associated RBAC are omitted in that mode.

The generated registry Secret is renewed by the Job and CronJob, but is not a
rendered Helm resource. It can remain after uninstall; its ECR token expires
within 12 hours.

For offline Harbor deployments, `values-harbor.yaml` in the repository root
overrides all four runtime image repositories and uses a precreated Harbor
pull Secret. The Helm chart itself is a separate OCI artifact, not an image.
